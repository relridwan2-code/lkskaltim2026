# KALTIM SMART PLATFORM

> LKS SMK 2026 — Provinsi Kalimantan Timur  
> Bidang Lomba: Cloud Computing  
> Peserta: **[Nama Peserta]** | Kode: **A01**

---

## Deskripsi Proyek

**Kaltim Smart Platform** adalah platform layanan publik digital berbasis REST API untuk Provinsi Kalimantan Timur. Platform ini dibangun di atas infrastruktur AWS dan dirancang untuk melayani ribuan warga secara bersamaan dengan ketersediaan tinggi.

Fitur utama:
- Autentikasi JWT dengan role-based access (admin / citizen)
- Pengajuan dan tracking permintaan layanan publik
- Pelaporan masalah lingkungan oleh warga
- Notifikasi otomatis saat status berubah
- Dashboard analitik untuk admin

---

## Diagram Arsitektur

![Architecture Diagram](docs/architecture-diagram.png)

---

## Teknologi yang Digunakan

| Layer | Teknologi |
|-------|-----------|
| Runtime | Node.js 20 + Express.js |
| Database | MySQL 8.0 (AWS RDS) |
| Cache | Redis 7 (Docker / ElastiCache) |
| Container | Docker + Docker Compose |
| IaC | Terraform >= 1.5 |
| Cloud | Amazon Web Services (ap-southeast-3) |
| Auth | JWT (jsonwebtoken) |
| ORM | Sequelize |

---

## Cara Menjalankan Lokal (Docker Compose)

```bash
# 1. Clone repository
git clone https://github.com/<username>/lks-kaltim-2026-A01.git
cd lks-kaltim-2026-A01

# 2. Salin dan isi environment variable
cp app/.env.example app/.env
# Edit app/.env — isi JWT_SECRET, DB_PASSWORD, dll.

# 3. Build & jalankan semua service
cd docker
docker-compose --env-file ../app/.env up -d --build

# 4. Jalankan migration + seeder
docker exec kaltim-app node src/utils/migrate.js
docker exec kaltim-app node src/utils/seeder.js

# 5. Cek kesehatan aplikasi
curl http://localhost:3000/health
```

Akun default setelah seeding:
- **Admin** → `admin@kaltim.go.id` / `admin123456`
- **Citizen** → `warga@example.com` / `user123456`

---

## Ringkasan Endpoint API

| Method | Endpoint | Auth | Deskripsi |
|--------|----------|------|-----------|
| POST | /auth/register | - | Registrasi pengguna |
| POST | /auth/login | - | Login, dapatkan JWT |
| POST | /auth/logout | ✅ | Logout |
| GET | /auth/profile | ✅ | Profil pengguna |
| GET | /services | - | Daftar jenis layanan |
| POST | /services/request | ✅ | Ajukan permintaan |
| GET | /services/request/:id | ✅ | Detail permintaan |
| PUT | /services/request/:id/status | 👑 Admin | Update status |
| GET | /services/requests | 👑 Admin | Semua permintaan |
| POST | /reports | ✅ | Kirim laporan |
| GET | /reports | ✅ | Daftar laporan |
| GET | /reports/:id | ✅ | Detail laporan |
| PUT | /reports/:id | ✅ | Update laporan |
| GET | /notifications | ✅ | Daftar notifikasi |
| PUT | /notifications/:id/read | ✅ | Tandai sudah dibaca |
| GET | /dashboard/stats | 👑 Admin | Statistik ringkasan |
| GET | /dashboard/reports/summary | 👑 Admin | Rekap laporan |

Dokumentasi lengkap: [docs/api-documentation.md](docs/api-documentation.md)

---

## Variabel Environment

Salin dari `app/.env.example`:

| Variable | Deskripsi |
|----------|-----------|
| `APP_PORT` | Port aplikasi (default: 3000) |
| `JWT_SECRET` | Secret key untuk JWT |
| `JWT_EXPIRES_IN` | Masa berlaku token (default: 24h) |
| `DB_HOST` | Host database |
| `DB_PORT` | Port database (default: 3306) |
| `DB_NAME` | Nama database |
| `DB_USER` | Username database |
| `DB_PASSWORD` | Password database |
| `REDIS_HOST` | Host Redis |
| `AWS_ACCESS_KEY_ID` | AWS access key |
| `AWS_SECRET_ACCESS_KEY` | AWS secret key |
| `AWS_REGION` | AWS region (default: ap-southeast-3) |
| `S3_BUCKET_NAME` | Nama S3 bucket |

---

## Struktur Direktori

```
lks-kaltim-2026-A01/
├── app/
│   ├── src/
│   │   ├── controllers/   # Logic handler tiap modul
│   │   ├── models/        # Sequelize models & relasi
│   │   ├── routes/        # Express router
│   │   ├── middleware/    # JWT auth & role guard
│   │   └── utils/         # Pagination, notifikasi, migrate, seeder
│   ├── package.json
│   ├── .env.example
│   └── README.md
├── docker/
│   ├── Dockerfile         # Multi-stage build, non-root user
│   └── docker-compose.yml # App + MySQL + Redis
├── terraform/
│   ├── main.tf            # Provider config
│   ├── variables.tf       # Semua variabel
│   ├── outputs.tf         # VPC ID, RDS endpoint, S3, ALB
│   ├── vpc.tf             # VPC, subnet, IGW, NAT, route tables
│   ├── ec2.tf             # EC2 + ALB + Target Group
│   ├── rds.tf             # RDS MySQL 8.0
│   ├── s3.tf              # S3 bucket upload
│   └── security.tf        # Security groups (least-privilege)
├── docs/
│   ├── architecture-diagram.png
│   ├── api-documentation.md
│   └── deployment-guide.md
└── README.md
```
