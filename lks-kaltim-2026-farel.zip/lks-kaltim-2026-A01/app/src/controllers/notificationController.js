const { Notification } = require('../models');
const { getPagination, paginatedResponse } = require('../utils/pagination');

// GET /notifications
const listNotifications = async (req, res, next) => {
  try {
    const { limit, offset, page } = getPagination(req.query);

    const { count, rows } = await Notification.findAndCountAll({
      where: { user_id: req.user.id },
      limit,
      offset,
      order: [['created_at', 'DESC']]
    });

    return res.json({
      success: true,
      message: 'Notifications retrieved',
      data: paginatedResponse(rows, count, page, limit)
    });
  } catch (error) {
    next(error);
  }
};

// PUT /notifications/:id/read
const markAsRead = async (req, res, next) => {
  try {
    const notif = await Notification.findOne({
      where: { id: req.params.id, user_id: req.user.id }
    });

    if (!notif) {
      return res.status(404).json({ success: false, message: 'Notification not found', data: null });
    }

    await notif.update({ is_read: true });
    return res.json({ success: true, message: 'Notification marked as read', data: notif });
  } catch (error) {
    next(error);
  }
};

module.exports = { listNotifications, markAsRead };
