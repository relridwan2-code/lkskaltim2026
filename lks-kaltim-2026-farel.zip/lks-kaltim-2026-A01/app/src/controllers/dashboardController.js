const { sequelize, User, Report, ServiceRequest, Notification } = require('../models');
const { QueryTypes } = require('sequelize');

// GET /dashboard/stats
const getStats = async (req, res, next) => {
  try {
    const totalUsers = await User.count({ where: { role: 'citizen' } });
    const totalReports = await Report.count();
    const totalRequests = await ServiceRequest.count();
    const openReports = await Report.count({ where: { status: 'open' } });
    const pendingRequests = await ServiceRequest.count({ where: { status: 'pending' } });
    const unreadNotifications = await Notification.count({ where: { is_read: false } });

    return res.json({
      success: true,
      message: 'Dashboard stats retrieved',
      data: {
        total_users: totalUsers,
        total_reports: totalReports,
        total_service_requests: totalRequests,
        open_reports: openReports,
        pending_requests: pendingRequests,
        unread_notifications: unreadNotifications
      }
    });
  } catch (error) {
    next(error);
  }
};

// GET /dashboard/reports/summary
const getReportsSummary = async (req, res, next) => {
  try {
    const summary = await sequelize.query(
      `SELECT category, status, COUNT(*) as count
       FROM reports
       GROUP BY category, status
       ORDER BY category, status`,
      { type: QueryTypes.SELECT }
    );

    // Group by category
    const grouped = summary.reduce((acc, row) => {
      if (!acc[row.category]) {
        acc[row.category] = { category: row.category, total: 0, statuses: {} };
      }
      acc[row.category].statuses[row.status] = parseInt(row.count);
      acc[row.category].total += parseInt(row.count);
      return acc;
    }, {});

    return res.json({
      success: true,
      message: 'Reports summary retrieved',
      data: Object.values(grouped)
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { getStats, getReportsSummary };
