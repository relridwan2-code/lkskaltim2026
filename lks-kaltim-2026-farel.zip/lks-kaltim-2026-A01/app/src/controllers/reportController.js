const { validationResult } = require('express-validator');
const { Op } = require('sequelize');
const { Report, User } = require('../models');
const { getPagination, paginatedResponse } = require('../utils/pagination');

// POST /reports
const createReport = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, message: 'Validation error', data: errors.array() });
    }

    const { category, title, description, location, image_url } = req.body;

    const report = await Report.create({
      user_id: req.user.id,
      category,
      title,
      description,
      location: location || null,
      image_url: image_url || null,
      status: 'open'
    });

    return res.status(201).json({ success: true, message: 'Report submitted', data: report });
  } catch (error) {
    next(error);
  }
};

// GET /reports
const listReports = async (req, res, next) => {
  try {
    const { limit, offset, page } = getPagination(req.query);

    const where = req.user.role === 'admin' ? {} : { user_id: req.user.id };

    const { count, rows } = await Report.findAndCountAll({
      where,
      limit,
      offset,
      include: [{ model: User, as: 'user', attributes: ['id', 'name', 'email'] }],
      order: [['created_at', 'DESC']]
    });

    return res.json({
      success: true,
      message: 'Reports retrieved',
      data: paginatedResponse(rows, count, page, limit)
    });
  } catch (error) {
    next(error);
  }
};

// GET /reports/:id
const getReport = async (req, res, next) => {
  try {
    const report = await Report.findByPk(req.params.id, {
      include: [{ model: User, as: 'user', attributes: ['id', 'name', 'email'] }]
    });

    if (!report) {
      return res.status(404).json({ success: false, message: 'Report not found', data: null });
    }

    if (req.user.role !== 'admin' && report.user_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied', data: null });
    }

    return res.json({ success: true, message: 'Report retrieved', data: report });
  } catch (error) {
    next(error);
  }
};

// PUT /reports/:id
const updateReport = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, message: 'Validation error', data: errors.array() });
    }

    const report = await Report.findByPk(req.params.id);
    if (!report) {
      return res.status(404).json({ success: false, message: 'Report not found', data: null });
    }

    // Citizens can only update their own reports; admin can update status too
    if (req.user.role !== 'admin' && report.user_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied', data: null });
    }

    const { title, description, location, status } = req.body;
    const updateData = {};
    if (title) updateData.title = title;
    if (description) updateData.description = description;
    if (location) updateData.location = location;
    if (status && req.user.role === 'admin') updateData.status = status;

    await report.update(updateData);
    return res.json({ success: true, message: 'Report updated', data: report });
  } catch (error) {
    next(error);
  }
};

module.exports = { createReport, listReports, getReport, updateReport };
