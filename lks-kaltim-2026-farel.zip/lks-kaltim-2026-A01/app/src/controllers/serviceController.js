const { validationResult } = require('express-validator');
const { ServiceType, ServiceRequest, User } = require('../models');
const { notifyServiceStatusChange } = require('../utils/notifications');
const { getPagination, paginatedResponse } = require('../utils/pagination');

// GET /services
const listServiceTypes = async (req, res, next) => {
  try {
    const types = await ServiceType.findAll({ order: [['id', 'ASC']] });
    return res.json({ success: true, message: 'Service types retrieved', data: types });
  } catch (error) {
    next(error);
  }
};

// POST /services/request
const createRequest = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, message: 'Validation error', data: errors.array() });
    }

    const { service_type_id, description, attachment_url } = req.body;

    const serviceType = await ServiceType.findByPk(service_type_id);
    if (!serviceType) {
      return res.status(404).json({ success: false, message: 'Service type not found', data: null });
    }

    const request = await ServiceRequest.create({
      user_id: req.user.id,
      service_type_id,
      description,
      attachment_url: attachment_url || null,
      status: 'pending'
    });

    return res.status(201).json({ success: true, message: 'Service request created', data: request });
  } catch (error) {
    next(error);
  }
};

// GET /services/request/:id
const getRequest = async (req, res, next) => {
  try {
    const request = await ServiceRequest.findOne({
      where: { id: req.params.id },
      include: [
        { model: User, as: 'user', attributes: ['id', 'name', 'email'] },
        { model: ServiceType, as: 'serviceType' }
      ]
    });

    if (!request) {
      return res.status(404).json({ success: false, message: 'Request not found', data: null });
    }

    // Citizens can only see their own requests
    if (req.user.role !== 'admin' && request.user_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied', data: null });
    }

    return res.json({ success: true, message: 'Request retrieved', data: request });
  } catch (error) {
    next(error);
  }
};

// PUT /services/request/:id/status  (admin only)
const updateRequestStatus = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, message: 'Validation error', data: errors.array() });
    }

    const { status } = req.body;
    const request = await ServiceRequest.findByPk(req.params.id);
    if (!request) {
      return res.status(404).json({ success: false, message: 'Request not found', data: null });
    }

    await request.update({ status });

    // Send notification to the user
    await notifyServiceStatusChange(request.user_id, request.id, status);

    return res.json({ success: true, message: 'Status updated', data: request });
  } catch (error) {
    next(error);
  }
};

// GET /services/requests  (admin only)
const listAllRequests = async (req, res, next) => {
  try {
    const { limit, offset, page } = getPagination(req.query);
    const { count, rows } = await ServiceRequest.findAndCountAll({
      limit,
      offset,
      include: [
        { model: User, as: 'user', attributes: ['id', 'name', 'email'] },
        { model: ServiceType, as: 'serviceType' }
      ],
      order: [['created_at', 'DESC']]
    });

    return res.json({
      success: true,
      message: 'All requests retrieved',
      data: paginatedResponse(rows, count, page, limit)
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { listServiceTypes, createRequest, getRequest, updateRequestStatus, listAllRequests };
