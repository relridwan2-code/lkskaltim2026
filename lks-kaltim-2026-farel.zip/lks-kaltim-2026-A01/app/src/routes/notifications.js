const express = require('express');
const router = express.Router();
const { listNotifications, markAsRead } = require('../controllers/notificationController');
const { authenticate } = require('../middleware/auth');

// GET /notifications
router.get('/', authenticate, listNotifications);

// PUT /notifications/:id/read
router.put('/:id/read', authenticate, markAsRead);

module.exports = router;
