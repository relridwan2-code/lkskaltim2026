const express = require('express');
const router = express.Router();
const { getStats, getReportsSummary } = require('../controllers/dashboardController');
const { authenticate, adminOnly } = require('../middleware/auth');

// GET /dashboard/stats
router.get('/stats', authenticate, adminOnly, getStats);

// GET /dashboard/reports/summary
router.get('/reports/summary', authenticate, adminOnly, getReportsSummary);

module.exports = router;
