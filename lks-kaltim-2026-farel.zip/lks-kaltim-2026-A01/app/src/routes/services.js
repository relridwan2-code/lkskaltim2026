const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const {
  listServiceTypes,
  createRequest,
  getRequest,
  updateRequestStatus,
  listAllRequests
} = require('../controllers/serviceController');
const { authenticate, adminOnly } = require('../middleware/auth');

// GET /services
router.get('/', listServiceTypes);

// POST /services/request
router.post('/request', authenticate, [
  body('service_type_id').isInt({ min: 1 }).withMessage('Valid service_type_id required'),
  body('description').trim().notEmpty().withMessage('Description is required'),
  body('attachment_url').optional().isURL().withMessage('attachment_url must be a valid URL'),
], createRequest);

// GET /services/requests  (admin only) — must be before /:id to avoid conflict
router.get('/requests', authenticate, adminOnly, listAllRequests);

// GET /services/request/:id
router.get('/request/:id', authenticate, getRequest);

// PUT /services/request/:id/status  (admin only)
router.put('/request/:id/status', authenticate, adminOnly, [
  body('status').isIn(['pending', 'processing', 'done', 'rejected']).withMessage('Invalid status'),
], updateRequestStatus);

module.exports = router;
