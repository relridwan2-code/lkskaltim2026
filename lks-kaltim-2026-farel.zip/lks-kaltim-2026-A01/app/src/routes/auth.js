const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const { register, login, logout, profile } = require('../controllers/authController');
const { authenticate } = require('../middleware/auth');

// POST /auth/register
router.post('/register', [
  body('name').trim().notEmpty().withMessage('Name is required'),
  body('email').isEmail().normalizeEmail().withMessage('Valid email is required'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
  body('phone').optional().isMobilePhone().withMessage('Valid phone number required'),
], register);

// POST /auth/login
router.post('/login', [
  body('email').isEmail().normalizeEmail().withMessage('Valid email is required'),
  body('password').notEmpty().withMessage('Password is required'),
], login);

// POST /auth/logout
router.post('/logout', authenticate, logout);

// GET /auth/profile
router.get('/profile', authenticate, profile);

module.exports = router;
