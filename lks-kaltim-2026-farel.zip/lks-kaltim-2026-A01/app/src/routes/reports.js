const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const { createReport, listReports, getReport, updateReport } = require('../controllers/reportController');
const { authenticate } = require('../middleware/auth');

// POST /reports
router.post('/', authenticate, [
  body('category').isIn(['infrastructure', 'environment', 'social', 'other']).withMessage('Invalid category'),
  body('title').trim().notEmpty().withMessage('Title is required'),
  body('description').trim().notEmpty().withMessage('Description is required'),
  body('location').optional().trim(),
  body('image_url').optional().isURL().withMessage('image_url must be a valid URL'),
], createReport);

// GET /reports
router.get('/', authenticate, listReports);

// GET /reports/:id
router.get('/:id', authenticate, getReport);

// PUT /reports/:id
router.put('/:id', authenticate, [
  body('title').optional().trim().notEmpty().withMessage('Title cannot be empty'),
  body('description').optional().trim().notEmpty().withMessage('Description cannot be empty'),
  body('status').optional().isIn(['open', 'in_progress', 'resolved']).withMessage('Invalid status'),
], updateReport);

module.exports = router;
