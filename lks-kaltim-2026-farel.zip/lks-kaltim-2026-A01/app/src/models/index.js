const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    port: process.env.DB_PORT || 3306,
    dialect: 'mysql',
    logging: process.env.APP_ENV === 'development' ? console.log : false,
    pool: {
      max: 10,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  }
);

// Import models
const User = require('./User')(sequelize);
const ServiceType = require('./ServiceType')(sequelize);
const ServiceRequest = require('./ServiceRequest')(sequelize);
const Report = require('./Report')(sequelize);
const Notification = require('./Notification')(sequelize);

// Associations
User.hasMany(ServiceRequest, { foreignKey: 'user_id', as: 'serviceRequests' });
ServiceRequest.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

ServiceType.hasMany(ServiceRequest, { foreignKey: 'service_type_id', as: 'requests' });
ServiceRequest.belongsTo(ServiceType, { foreignKey: 'service_type_id', as: 'serviceType' });

User.hasMany(Report, { foreignKey: 'user_id', as: 'reports' });
Report.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

User.hasMany(Notification, { foreignKey: 'user_id', as: 'notifications' });
Notification.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

module.exports = {
  sequelize,
  User,
  ServiceType,
  ServiceRequest,
  Report,
  Notification
};
