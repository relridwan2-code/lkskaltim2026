const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const ServiceType = sequelize.define('ServiceType', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    name: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    estimated_days: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 7
    }
  }, {
    tableName: 'service_types',
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: false
  });

  return ServiceType;
};
