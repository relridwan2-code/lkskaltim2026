/**
 * Parse pagination parameters from query string
 * @param {Object} query - Express req.query
 * @returns {Object} { limit, offset, page }
 */
const getPagination = (query) => {
  const page = Math.max(1, parseInt(query.page) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(query.limit) || 10));
  const offset = (page - 1) * limit;
  return { limit, offset, page };
};

/**
 * Format paginated response
 */
const paginatedResponse = (rows, count, page, limit) => {
  const totalPages = Math.ceil(count / limit);
  return {
    items: rows,
    pagination: {
      total: count,
      page,
      limit,
      totalPages,
      hasNext: page < totalPages,
      hasPrev: page > 1
    }
  };
};

module.exports = { getPagination, paginatedResponse };
