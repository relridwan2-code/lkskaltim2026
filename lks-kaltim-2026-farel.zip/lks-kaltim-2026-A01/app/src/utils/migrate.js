require('dotenv').config();
const { sequelize } = require('../models');

const migrate = async () => {
  try {
    await sequelize.authenticate();
    console.log('Connected to database.');
    await sequelize.sync({ force: false, alter: true });
    console.log('All tables migrated/synced successfully.');
    process.exit(0);
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  }
};

migrate();
