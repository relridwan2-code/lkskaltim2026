const { Notification } = require('../models');

/**
 * Create a notification for a user
 */
const createNotification = async (userId, message, type = 'info', referenceId = null, referenceType = null) => {
  try {
    await Notification.create({
      user_id: userId,
      message,
      type,
      is_read: false,
      reference_id: referenceId,
      reference_type: referenceType
    });
  } catch (error) {
    console.error('Failed to create notification:', error.message);
  }
};

/**
 * Notify user about service request status change
 */
const notifyServiceStatusChange = async (userId, requestId, newStatus) => {
  const statusMessages = {
    processing: 'Permintaan layanan Anda sedang diproses.',
    done: 'Permintaan layanan Anda telah selesai.',
    rejected: 'Permintaan layanan Anda ditolak.'
  };
  const message = statusMessages[newStatus] || `Status permintaan layanan Anda diperbarui menjadi: ${newStatus}`;
  await createNotification(userId, message, 'service_update', requestId, 'service_request');
};

module.exports = { createNotification, notifyServiceStatusChange };
