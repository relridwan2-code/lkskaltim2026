require('dotenv').config();
const bcrypt = require('bcryptjs');
const { sequelize, User, ServiceType } = require('../models');

const seed = async () => {
  try {
    await sequelize.authenticate();
    console.log('Connected. Running seeders...');

    // ── Users ────────────────────────────────────────────────────────────────
    const adminHash = await bcrypt.hash('admin123456', 12);
    const userHash  = await bcrypt.hash('user123456', 12);

    await User.findOrCreate({
      where: { email: 'admin@kaltim.go.id' },
      defaults: {
        name: 'Administrator',
        email: 'admin@kaltim.go.id',
        password_hash: adminHash,
        role: 'admin',
        phone: '08111000001',
        address: 'Kantor Gubernur Kaltim, Samarinda'
      }
    });

    await User.findOrCreate({
      where: { email: 'warga@example.com' },
      defaults: {
        name: 'Budi Santoso',
        email: 'warga@example.com',
        password_hash: userHash,
        role: 'citizen',
        phone: '08111000002',
        address: 'Jl. Merdeka No.1, Samarinda'
      }
    });

    console.log('✔ Users seeded');

    // ── Service Types ─────────────────────────────────────────────────────────
    const serviceTypes = [
      { name: 'Pembuatan KTP',          description: 'Permohonan pembuatan Kartu Tanda Penduduk baru', estimated_days: 7 },
      { name: 'Pembuatan Akta Kelahiran', description: 'Permohonan akta kelahiran untuk bayi baru lahir', estimated_days: 14 },
      { name: 'Surat Keterangan Domisili', description: 'Permohonan surat keterangan domisili warga', estimated_days: 3 },
      { name: 'Pembuatan KK',            description: 'Permohonan pembuatan Kartu Keluarga baru', estimated_days: 10 },
      { name: 'Perizinan Usaha',         description: 'Permohonan izin usaha mikro dan kecil', estimated_days: 21 },
    ];

    for (const st of serviceTypes) {
      await ServiceType.findOrCreate({ where: { name: st.name }, defaults: st });
    }

    console.log('✔ Service types seeded');
    console.log('\nSeeding complete!');
    console.log('Admin    → admin@kaltim.go.id   / admin123456');
    console.log('Citizen  → warga@example.com    / user123456');
    process.exit(0);
  } catch (error) {
    console.error('Seeding failed:', error);
    process.exit(1);
  }
};

seed();
