# Kaltim Smart Platform — App

REST API berbasis Node.js + Express untuk platform layanan publik digital Kalimantan Timur.

## Development

```bash
npm install
cp .env.example .env
# Edit .env
npm run migrate
npm run seed
npm run dev
```

## Production (via Docker)

```bash
cd ../docker
docker-compose up -d --build
```
