# API Documentation — Kaltim Smart Platform

Base URL: `http://<ALB_DNS>/`

Semua response menggunakan format:
```json
{ "success": true, "message": "...", "data": {...} }
```

Header autentikasi: `Authorization: Bearer <JWT_TOKEN>`

---

## A. Modul Autentikasi

### POST /auth/register
Registrasi pengguna baru.

**Body:**
```json
{
  "name": "Budi Santoso",
  "email": "budi@example.com",
  "password": "password123",
  "phone": "081234567890",
  "address": "Jl. Merdeka No.1, Samarinda"
}
```
**Response 201:**
```json
{
  "success": true,
  "message": "User registered successfully",
  "data": { "id": 1, "name": "Budi Santoso", "email": "budi@example.com", "role": "citizen" }
}
```

---

### POST /auth/login
Login dan dapatkan JWT token.

**Body:**
```json
{ "email": "budi@example.com", "password": "password123" }
```
**Response 200:**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "token": "eyJhbGci...",
    "user": { "id": 1, "name": "Budi Santoso", "role": "citizen" }
  }
}
```

---

### POST /auth/logout
Logout pengguna. `🔒 Auth required`

**Response 200:**
```json
{ "success": true, "message": "Logged out successfully", "data": null }
```

---

### GET /auth/profile
Lihat profil pengguna. `🔒 Auth required`

**Response 200:**
```json
{
  "success": true,
  "message": "Profile retrieved",
  "data": { "id": 1, "name": "Budi", "email": "budi@example.com", "role": "citizen" }
}
```

---

## B. Modul Layanan Publik

### GET /services
Daftar semua jenis layanan publik (public).

**Response 200:**
```json
{
  "success": true,
  "message": "Service types retrieved",
  "data": [
    { "id": 1, "name": "Pembuatan KTP", "description": "...", "estimated_days": 7 }
  ]
}
```

---

### POST /services/request
Ajukan permintaan layanan. `🔒 Auth required`

**Body:**
```json
{
  "service_type_id": 1,
  "description": "Permohonan pembuatan KTP baru",
  "attachment_url": "https://s3.amazonaws.com/..."
}
```

---

### GET /services/request/:id
Lihat status permintaan. `🔒 Auth required`

---

### PUT /services/request/:id/status
Update status permintaan. `🔒 Admin only`

**Body:**
```json
{ "status": "processing" }
```
Status: `pending` | `processing` | `done` | `rejected`

---

### GET /services/requests
Daftar semua permintaan. `🔒 Admin only`

Query params: `?page=1&limit=10`

---

## C. Modul Laporan Warga

### POST /reports
Kirim laporan masalah. `🔒 Auth required`

**Body:**
```json
{
  "category": "infrastructure",
  "title": "Jalan Berlubang di Jl. Ahmad Yani",
  "description": "Terdapat lubang besar yang membahayakan",
  "location": "Jl. Ahmad Yani KM 5",
  "image_url": "https://s3.amazonaws.com/..."
}
```
Category: `infrastructure` | `environment` | `social` | `other`

---

### GET /reports
Daftar laporan. `🔒 Auth required`
- Admin: melihat semua laporan
- Citizen: hanya miliknya

Query params: `?page=1&limit=10`

---

### GET /reports/:id
Detail laporan. `🔒 Auth required`

---

### PUT /reports/:id
Update laporan. `🔒 Auth required`

---

## D. Modul Notifikasi

### GET /notifications
Daftar notifikasi pengguna. `🔒 Auth required`

Query params: `?page=1&limit=10`

---

### PUT /notifications/:id/read
Tandai notifikasi sudah dibaca. `🔒 Auth required`

---

## E. Modul Dashboard (Admin)

### GET /dashboard/stats
Statistik ringkasan. `🔒 Admin only`

**Response:**
```json
{
  "success": true,
  "message": "Dashboard stats retrieved",
  "data": {
    "total_users": 120,
    "total_reports": 45,
    "total_service_requests": 88,
    "open_reports": 12,
    "pending_requests": 20,
    "unread_notifications": 5
  }
}
```

---

### GET /dashboard/reports/summary
Rekapitulasi laporan per kategori. `🔒 Admin only`

**Response:**
```json
{
  "success": true,
  "message": "Reports summary retrieved",
  "data": [
    { "category": "infrastructure", "total": 20, "statuses": { "open": 10, "in_progress": 7, "resolved": 3 } },
    { "category": "environment", "total": 15, "statuses": { "open": 5, "in_progress": 4, "resolved": 6 } }
  ]
}
```

---

## Error Responses

| Code | Deskripsi |
|------|-----------|
| 401  | Token tidak ada / expired |
| 403  | Akses ditolak (role tidak sesuai) |
| 404  | Resource tidak ditemukan |
| 409  | Conflict (email sudah terdaftar) |
| 422  | Validation error |
| 500  | Internal server error |
