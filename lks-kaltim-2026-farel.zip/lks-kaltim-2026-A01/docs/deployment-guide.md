# Deployment Guide — Kaltim Smart Platform

## 1. Prasyarat

- Docker & Docker Compose terinstall
- AWS CLI terinstall & terkonfigurasi (`aws configure`)
- Terraform >= 1.5.0 terinstall
- Node.js >= 18 (untuk development lokal)

---

## 2. Menjalankan Lokal dengan Docker Compose

```bash
# 1. Clone repository
git clone https://github.com/<username>/lks-kaltim-2026-A01.git
cd lks-kaltim-2026-A01

# 2. Salin dan isi environment variable
cp app/.env.example app/.env
# Edit app/.env sesuai kebutuhan

# 3. Build dan jalankan semua service
cd docker
docker-compose --env-file ../app/.env up -d --build

# 4. Jalankan migration database
docker exec kaltim-app node src/utils/migrate.js

# 5. Cek status
docker-compose ps
curl http://localhost:3000/health
```

---

## 3. Deploy ke AWS dengan Terraform

```bash
cd terraform

# 1. Inisialisasi Terraform
terraform init

# 2. Buat file terraform.tfvars
cat > terraform.tfvars << EOF
aws_region    = "ap-southeast-3"
db_password   = "YourSecurePassword123!"
key_name      = "your-keypair-name"
s3_bucket_name = "kaltim-smart-platform-uploads-yourcode"
EOF

# 3. Lihat rencana infrastruktur
terraform plan

# 4. Deploy infrastruktur
terraform apply -auto-approve

# 5. Catat output (RDS endpoint, ALB DNS, S3 bucket)
terraform output
```

---

## 4. Deploy Aplikasi ke EC2

```bash
# 1. SSH ke EC2 via Bastion atau Session Manager
ssh -i your-keypair.pem ec2-user@<EC2_PRIVATE_IP>

# 2. Clone repository di EC2
git clone https://github.com/<username>/lks-kaltim-2026-A01.git
cd lks-kaltim-2026-A01/docker

# 3. Buat .env dengan nilai dari Terraform output
cat > ../.env << EOF
JWT_SECRET=your_jwt_secret
DB_HOST=<RDS_ENDPOINT>
DB_NAME=kaltim_smart_platform
DB_USER=kaltim_admin
DB_PASSWORD=YourSecurePassword123!
DB_ROOT_PASSWORD=rootpassword
AWS_ACCESS_KEY_ID=<AWS_KEY>
AWS_SECRET_ACCESS_KEY=<AWS_SECRET>
S3_BUCKET_NAME=kaltim-smart-platform-uploads-yourcode
EOF

# 4. Jalankan aplikasi
docker-compose --env-file ../.env up -d --build

# 5. Jalankan migration
docker exec kaltim-app node src/utils/migrate.js
```

---

## 5. Menghapus Infrastruktur

```bash
cd terraform
terraform destroy -auto-approve
```

---

## 6. Troubleshooting

| Masalah | Solusi |
|---------|--------|
| Container app tidak mau start | Cek `docker logs kaltim-app`, pastikan DB sudah healthy |
| DB connection error | Pastikan `DB_HOST`, `DB_USER`, `DB_PASSWORD` di .env sudah benar |
| Terraform error provider | Jalankan `terraform init -upgrade` |
| ALB tidak bisa akses app | Cek security group, pastikan port 3000 terbuka dari ALB SG |
